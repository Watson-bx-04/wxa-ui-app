const { IamAuthenticator } = require('ibm-watson/auth');
const Assistant = require('ibm-watson/assistant/v2');
require('dotenv').config();

const assistant = new Assistant({
  version: '2023-06-15',
  authenticator: new IamAuthenticator({
    apikey: process.env.WATSONX_ASSISTANT_API_KEY,
  }),
  serviceUrl: process.env.WATSONX_ASSISTANT_URL,
});

module.exports = assistant;