let sessionId = null;

async function startChat() {
    try {
        const response = await fetch('/api/chat/start', {
            method: 'POST'
        });
        const data = await response.json();
        sessionId = data.sessionId;
        addMessage('こんにちは！どのようなお手伝いができますか？', 'bot');
    } catch (error) {
        console.error('Error starting chat:', error);
    }
}

async function sendMessage(message) {
    if (!sessionId || !message) return;

    try {
        addMessage(message, 'user');
        
        const response = await fetch('/api/chat/message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ sessionId, message })
        });
        
        const data = await response.json();
        const botResponse = data.output.generic[0]?.text || 'すみません、よく理解できませんでした。';
        addMessage(botResponse, 'bot');
    } catch (error) {
        console.error('Error sending message:', error);
    }
}

function addMessage(text, sender) {
    const messagesContainer = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    
    const content = document.createElement('div');
    content.className = 'message-content';
    content.textContent = text;
    
    messageDiv.appendChild(content);
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

document.addEventListener('DOMContentLoaded', () => {
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');

    startChat();

    sendButton.addEventListener('click', () => {
        const message = messageInput.value.trim();
        if (message) {
            sendMessage(message);
            messageInput.value = '';
        }
    });

    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const message = messageInput.value.trim();
            if (message) {
                sendMessage(message);
                messageInput.value = '';
            }
        }
    });
});

window.addEventListener('beforeunload', async () => {
    if (sessionId) {
        try {
            await fetch(`/api/chat/end/${sessionId}`, {
                method: 'DELETE'
            });
        } catch (error) {
            console.error('Error ending chat:', error);
        }
    }
});