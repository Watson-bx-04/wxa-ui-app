const assistant = require('../config/watsonConfig');

class ChatService {
  async createSession() {
    try {
      const response = await assistant.createSession({
        assistantId: process.env.WATSONX_ASSISTANT_ID,
      });
      return response.result.session_id;
    } catch (error) {
      console.error('Error creating session:', error);
      throw error;
    }
  }

  async sendMessage(sessionId, message) {
    try {
      const response = await assistant.message({
        assistantId: process.env.WATSONX_ASSISTANT_ID,
        sessionId: sessionId,
        input: {
          message_type: 'text',
          text: message,
        },
      });
      return response.result;
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  }

  async deleteSession(sessionId) {
    try {
      await assistant.deleteSession({
        assistantId: process.env.WATSONX_ASSISTANT_ID,
        sessionId: sessionId,
      });
    } catch (error) {
      console.error('Error deleting session:', error);
      throw error;
    }
  }
}

module.exports = new ChatService();