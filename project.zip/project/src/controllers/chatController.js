const chatService = require('../services/chatService');

class ChatController {
  async startChat(req, res) {
    try {
      const sessionId = await chatService.createSession();
      res.json({ sessionId });
    } catch (error) {
      res.status(500).json({ error: 'Failed to start chat session' });
    }
  }

  async sendMessage(req, res) {
    const { sessionId, message } = req.body;
    
    if (!sessionId || !message) {
      return res.status(400).json({ error: 'Session ID and message are required' });
    }

    try {
      const response = await chatService.sendMessage(sessionId, message);
      res.json(response);
    } catch (error) {
      res.status(500).json({ error: 'Failed to process message' });
    }
  }

  async endChat(req, res) {
    const { sessionId } = req.params;
    
    if (!sessionId) {
      return res.status(400).json({ error: 'Session ID is required' });
    }

    try {
      await chatService.deleteSession(sessionId);
      res.json({ message: 'Chat session ended successfully' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to end chat session' });
    }
  }
}

module.exports = new ChatController();